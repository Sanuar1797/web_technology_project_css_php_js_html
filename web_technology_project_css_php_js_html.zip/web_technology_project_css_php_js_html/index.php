<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Home Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
 	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 </head>

 <body>

 <h3 algin="center">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <font face="cinzel" size="4">
            <a href="product.php"> All product </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="aboutus.php"> About Us </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="change_password.php"> Change Password </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="delete_profile.php"> Delete Profile </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="logout.php"> Logout </a>&nbsp;&nbsp;&nbsp;&nbsp;
        </font>
    </h3>

	
	


	
	
	
	


</body>
</html>
    
























































































































<!-- <br/><br/>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="card mx-auto">
				  <img class="card-img-top mx-auto" style="width:60%;" src="./img/user.png" alt="Card image cap">
				  <div class="card-body">
				    <h4 class="card-title">Profile Info</h4>
				    <p class="card-text"><i class="fa fa-user">&nbsp;</i>Sanuar Hossain</p>
				    <p class="card-text"><i class="fa fa-user">&nbsp;</i>Admin</p>
				    <p class="card-text">Last Login : xxxx-xx-xx</p>
				    <a href="update_profile.php" class="btn btn-primary"><i class="fa fa-edit">&nbsp;</i>Edit Profile</a>
				  </div>
				</div>
			</div>
			<div class="col-md-8">
				<div class="jumbotron" style="width:100%;height:100%;">
					<h1>Welcome Admin,</h1>
					<div class="row">
						<div class="col-sm-6">
								<iframe src="https://www.timeanddate.com/worldclock/fullscreen.html?n=73" frameborder="4" width="260" height="160"></iframe>
						</div>
						<div class="col-sm-6">
							<div class="card">
						      <div class="card-body">
						        <h4 class="card-title">New Orders</h4>
						        <p class="card-text">Here you can create new orders</p>
						        <a href="new_order.php" class="btn btn-primary">New Orders</a>
						      </div>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<p></p>
	<p></p> -->







<!-- <div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Categories</h4>
						<p class="card-text">Here you can add & manage your categories</p>
						<input type="submit" value="Add" name="add" class="btn btn-primary">
						<input type="submit" value="Manage" name="manage" class="btn btn-primary">
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Brands</h4>
						<p class="card-text">Here you can manage your brand & you add new brand</p>
						<input type="submit" value="Add" name="add" class="btn btn-primary">
						<input type="submit" value="Manage" name="manage" class="btn btn-primary">
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Products</h4>
						<p class="card-text">Here you can manage your prpducts & you add new products</p>
						<input type="submit" value="Add" name="add" class="btn btn-primary">
						<input type="submit" value="Manage" name="manage" class="btn btn-primary">
					</div>
				</div>
			</div>
		</div>
	</div> -->


	
	<!-- <?php
	//Categpry Form
	include_once("./templates/category.php");
	 ?>
	 <?php
	//Brand Form
	include_once("./templates/brand.php");
	 ?>
	 <?php
	//Products Form
	include_once("./templates/products.php");
	 ?> -->










<!-- <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce Website</title>
    <link rel="stylesheet" href="index.css">
</head>
<body background="log3.jpg" link="#000" alink="#17bf5 vlink="#000> -->



<!-- </br>
    <h3 algin="center">
        <font face="Loto" size="6">Admin</font>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <font face="cinzel" size="4">
            <a href="product.php"> All product </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="aboutus.php"> About Us </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="change_password.php"> Change Password </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="update_profile.php"> Update Profile </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="delete_profile.php"> Delete Profile </a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="logout.php"> Logout </a>&nbsp;&nbsp;&nbsp;&nbsp;
        </font>
    </h3>
    <br/><br/><br/><br/><br/><br/><br/>
    <h1 align="center">
        <font face="Loto" color="#17bf5" size="7">
            Welcome To E-Commerce Website
        </font>
    </h1> -->

    <!-- <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo"><img src="../img/pc.jpg" alt="logo"></div>
            <li><a href="product.php"> All product </a></li>
            <li><a href="aboutus.php"> About Us </a></li>
            <li><a href="change_password.php"> Change Password </a></li>
            <li><a href="update_profile.php"> Update Profile </a></li>
            <li><a href="delete_profile.php"> Delete Profile </a></li>
            <li><a href="logout.php"> Logout </a></li>

        </ul>
        <div class="rightNav">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>
    
    </nav> -->

    <!-- <div class="container">
        <h1>Welcome to E-Commerce Website</h1>
        <a href="logout.php" class="btn btn-warning">Logout</a>
        <div><p>All Products <a href="product.php">Click Here</a></p></div>
    <div><p>Do you change password ? <a href="change_password.php">Click Here</a></p></div>
    <div><p>About Us <a href="aboutus.php">Click Here</a></p></div>
    <div><p>Update Profile? <a href="update_profile.php">Click Here</a></p></div>
    <div><p>Delete Profile <a href="delete_profile.php">Click Here</a></p></div>
    </div> -->


    