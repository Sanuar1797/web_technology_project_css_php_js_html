<?php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "login_register";

$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST["password"];
    $newPassword = password_hash($_POST["new_password"], PASSWORD_DEFAULT);

    $sql = "UPDATE users SET password='$newPassword' WHERE password='$password'";

    if (mysqli_query($conn, $sql)) {
        echo "Password updated successfully";
    } else {
        echo "Error updating password: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Change Page</title>
    <link rel="stylesheet" href="change_password.css">
    <script src="external.js"></script>
</head>
<body>
    <div class="container">
    <form onsubmit="return isValidChangePass(this)" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form" method="post" novalidate>
        <h2>Password Change</h2>
        <div class="form-control">
            <!-- Current Password:  -->
            <label for="password">Password:</label>
            <input type="password" name="password" placeholder="Enter Current Password:" required><br>
            <span id="passErr"></span>
        </div>
        <div class="form-control">
            <!-- New Password:  -->
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" placeholder="Enter New Password:" required><br>
            <span id="newpassErr"></span>
        </div>
        <div class="form-control">
            <input type="submit" value="Change Password">
        </div>

        <div class="link">
            <p>Go to Home !! <a href="index.php">Click Here</a></p>
        </div>
    </form>

    </div>
    
</body>
</html>


