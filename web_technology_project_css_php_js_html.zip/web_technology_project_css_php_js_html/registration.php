<?php
session_start();
if (isset($_SESSION["user"])) 
{
   header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="registration.css">
    <script src="external.js"></script>
</head>

    
<body>
    <div class="container">
        <!-- <div class="req"> -->
        <?php

        if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) 
        {
           $fullName = $_POST["fullname"];
           $email = $_POST["email"];
           $password = $_POST["password"];
           $passwordRepeat = $_POST["repeat_password"];
           $security_answer = $_POST["security_answer"];

           $passwordHash = password_hash($password, PASSWORD_DEFAULT);

           $errors = array();
           
           if (empty($fullName) OR empty($email) OR empty($password) OR empty($passwordRepeat) OR empty($security_answer)) 
           {
            array_push($errors,"All fields are required");
           }
           
           else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
           {
            array_push($errors, "Email is not valid");
           }
           else if (strlen($password)<8) 
           {
            array_push($errors,"Password must be at least 8 charactes long");
           }
           else if ($password!==$passwordRepeat) 
           {
            array_push($errors,"Password does not match");
           }
           
           require_once "database.php";
           $sql = "SELECT * FROM users WHERE email = '$email'";
           $result = mysqli_query($conn, $sql);
           $rowCount = mysqli_num_rows($result);
           if ($rowCount>0) 
           {
                array_push($errors,"Email already exists!");
           }
           
           if (count($errors)>0) 
           {
               foreach ($errors as  $error) 
               {
                // echo "<div class='alert alert-danger'>$error</div>";
                echo $error;
               }
           }
           else
           {
            
            $sql = "INSERT INTO users (full_name, email, password, security_answer) VALUES ( ?, ?, ?, ? )";
            $stmt = mysqli_stmt_init($conn);
            $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
            if ($prepareStmt) 
            {
                mysqli_stmt_bind_param($stmt,"ssss",$fullName, $email, $passwordHash, $security_answer);
                mysqli_stmt_execute($stmt);
                // echo "<div class='alert alert-success'>You are registered successfully.</div>";
                echo "Registration Successful";
            }else{
                die("Something went wrong");
            }
           }
           //Sanitizaion

           $fullName=sanitize($fullName);
           $email=sanitize($email);
           $password=sanitize($password);
           $passwordRepeat=sanitize($passwordRepeat);
          

        }

        function sanitize($data)
      {
        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;
      }

        ?>
        <!-- </div> -->
        
            <!-- <div class="loginBody"> -->
            <div class="form-group">
                <!-- <p><span class="error">* required field</span></p> -->
                
                <!-- <div class="form" id="form"> -->

                <!-- <form class="form" id="form" action="registration.php" method="post" novalidate> -->
                <!-- <form onsubmit="return isValidReg(this)" class="form" id="form" action="registration.php" method="post" novalidate> -->
                <form onsubmit="return isValidReg(this)" class="form" id="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" novalidate>
                      
                <div class="form-control">
                    <div>
                        <label for="fullname">Full Name </label>
                        <input type="text" name="fullname" placeholder="Full Name:">
                        <span id="fnameErr"></span>
                    </div>
                
                    <div >
                        <label for="email">Email </label>
                        <input type="text" name="email" placeholder="Email:">
                        <span id="emailErr"></span>
                    </div>
                    <div>
                        <label for="password">Password </label>
                        <input type="password" name="password" placeholder="Password:">
                        <span id="passErr"></span>
                    </div>
                    <div>
                        <label for="repeat_password">Confirm Password </label>
                        <input type="password" name="repeat_password" placeholder="Repeat Password:">
                        <span id="repeatPassErr"></span>
                    </div>
            

                
                    <label for="security_question">Security Question:</label>
                    <select name="security_question" required>
                    <option value="What is your favorite color?">What is your favorite color?</option>
                    </select><br>

                    <label for="security_answer">Security Answer:</label>
                    <input type="text" name="security_answer" required><br>
                    <span id="securityErr"></span>
                </div>


                <div class="form-control">
                   <!-- <input type="submit" value="Register" name="submit" class="btn btn-primary"> -->
                   <input type="submit" value="Register" name="submit">
                </div>
                <!-- </div> -->
                
                <div class="link">
                   <div><p>Already Registered ?   <a href="login.php">Login Here</a></p></div>
                </div>

                </form>

                <!-- <div class="link">
                   <div><p>Already Registered <a href="login.php">Login Here</a></p></div>
                </div> -->
            </div>


            
            
    
    </div>

    <!-- <script src="registration.js"></script> -->
</body>

</html>