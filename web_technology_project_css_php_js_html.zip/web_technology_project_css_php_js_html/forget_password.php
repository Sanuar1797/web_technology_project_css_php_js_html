<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="forget_password.css">
    <script src="external.js"></script>
</head>
<body>
<div class="container">
    <!-- <form onsubmit="return isValidForget(this)" class="form" id="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" action="recover_password.php" class="form" method="post" novalidate> -->
    <form onsubmit="return isValidForget(this)" class="form" id="form" action="recover_password.php" class="form" method="post" novalidate>
    <h2>Forgot Password</h2>
        <div class="form-control">
        <label for="fullname">fullname:</label>
        <input type="text" name="fullname" required><br>
        <span id="fnameErr"></span>
        </div>

        <div class="form-control">
        <label for="security_answer">Security Answer:</label>
        <input type="text" name="security_answer" required><br>
        <span id="securityErr"></span>
        </div>

        <div class="form-control">
        <input type="submit" value="Recover Password">
        </div>

        <div class="link">
            <!-- <p>Go to Home !! <a href="index.php">Click Here</a></p> -->
            <a href="login.php"> Login </a>
            
        </div>
    </form>
</div>
    <!-- <script src="forget_password.js"></script> -->
</body>
</html>
