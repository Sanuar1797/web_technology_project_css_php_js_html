<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Full Name and Email</title>
    <link rel="stylesheet" href="update_profile.css">
    <script src="external.js"></script>
</head>
<body>
<div class="container"> 


<?php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "login_register";

$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $currentEmail = $_POST["email"];
    $newFullName = $_POST["new_fullname"];
    $newEmail = $_POST["new_email"];

    $emailCheckQuery = "SELECT * FROM users WHERE email='$newEmail'";
    $emailCheckResult = mysqli_query($conn, $emailCheckQuery);

    if (mysqli_num_rows($emailCheckResult) > 0) {
        echo "Error: The new email is already in use.";
    } else {
        
        $sql = "UPDATE users SET full_name='$newFullName', email='$newEmail' WHERE email='$currentEmail'";


        if (mysqli_query($conn, $sql)) {
            echo "Full Name and Email updated successfully";
        } else {
            echo "Error updating Full Name and Email: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>




   
<form onsubmit="return isValidUpdate(this)" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form" method="post" novalidate>
        <h2>Change Full Name and Email</h2>
        <div class="form-control">
           <label for="email">Current Email:</label>
           <input type="email" placeholder="currentEmail:" name="email" required><br>
           <span id="emailErr"></span>
        </div>
        <div class="form-control">
           <label for="new_fullname">New Name: </label>
           <input type="text" placeholder="New Name" name="new_fullname" required><br>
           <span id="newfnameErr"></span>
        </div>
        <div class="form-control">
           <label for="new_email">New Email: </label> 
           <input type="email" name="new_email" placeholder="New Email"  required><br>
           <span id="newemailErr"></span>
        </div>
        <div class="form-control">
           <input type="submit" value="Change Full Name and Email">
        </div>
        <div class="link">
            <!-- <p>Go to Home ! <a href="index.php">Click Here</a></p> -->
            <a href="index.php"> GO to Home </a>
        </div>
    </form>

</div>
    
</body>
</html>
