<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
}
If(isset($_COOKIE['email']) && isset($_COOKIE['password'])){
    $id=$_COOKIE['email'];
    $pass=$_COOKIE['password'];
}
else{
    $id="";
    $pass="";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="login.css">
    <script src="external.js"></script>
    
</head>
<div class="loginHeader">
            <h1>E-Commerce</h1>
            <h3>E-Commerce Website</h3>
</div>
<body id="loginBody">

    <div class="container">
        
        <?php
        
        if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
           $email = $_POST["email"];
           $password = $_POST["password"];
        
           $errors = array();
           
           require_once "database.php";
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            
            if ($user) {
                if (password_verify($password, $user["password"])) {
                    session_start();
                    $_SESSION["user"] = "yes";

                    if(isset($_POST['remember']))
                    {
                        setcookie('email',$_POST['email'],time()+ (60*60));
                        setcookie('password',$_POST['password'],time()+ (60*60));
                    }

                    header("Location: index.php");
                    die();
                }else{
                    echo "Password does not match";
                }
            }else{
                echo "Email Does not Match";
            }
        }
        ?>
        
        <div class="loginBody">
            <!-- <form class="form" id="form" action="login.php" method="post" novalidate> -->
            <form onsubmit="return isValid(this)" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form" method="post" novalidate>
            
            <div class="form-group">
                <div>
                  <label for="">Email </label>
                  <input type="email" placeholder="Enter Email:" name="email" class="form-control" value="<?php echo $id ?>">
                  <span id="emailErr"></span>
                </div>
                <div>
                  <label for="">password </label>
                  <input type="password" placeholder="Enter Password:" name="password" class="form-control" value="<?php echo $pass ?>">
                  <span id="passErr"></span>
                </div>
                <div class="remember">
                <label>
                   <input type="checkbox" name="remember"> Remember Me
                </label>
                </div>

            </div>
            <div class="form-btn">
               <input type="submit" value="Login" name="login" class="btn btn-primary">
            </div>

            </form>

            <div class="link">
               <div><p>Forgotten Password? <a href="forget_password.php">Click Here</a></p></div>
               <div><p>Not registered yet <a href="registration.php">Register Here</a></p></div>
            </div>
        </div>
    </div>
    

</body>
</html>