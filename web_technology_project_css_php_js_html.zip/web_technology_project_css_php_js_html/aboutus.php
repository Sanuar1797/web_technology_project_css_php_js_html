<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>About Us</h1>

        <p>Welcome to our website! We want a give you a best service. Please buy as you want.</p>

        <h2>Out Mission</h2>
        <p>We create this website for building a good heliping online service to our customer.</p>

        <h2>Our Team</h2>
        <?php
        
        $teamMembers = array(
            'Sanuar Hossain' => 'CEO',
            'Abdullah Al Mamun' => 'Managing Director',
            'Dosina Dolon Dola' => 'Head of IT',
            
        );
        ?>

        <ul>
            <?php foreach ($teamMembers as $name => $position): ?>
                <li><strong><?php echo $name; ?>:</strong> <?php echo $position; ?></li>
            <?php endforeach; ?>
        </ul>

        <h2>Contact Us</h2>
        <p>Feel free to contact us at <a href="sanuarhossain111@gmail.com">sanuarhossain111@gmail.com</a>.</p>
    </div>
    <div><p>Go to Home !! <a href="index.php">Click Here</a></p></div>
</body>
</html>
