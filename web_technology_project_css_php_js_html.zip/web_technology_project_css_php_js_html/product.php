<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Page</title>
    <style>
        .product-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .product {
            margin: 10px;
            text-align: center;
        }

        .product img {
            width: 200px;
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <h1>Product Page</h1>

    <div class="product-container">
        <div class="product">
            <img src="iphone14.jpg" alt="iphone14" width="300" height="200">
            <h3>I-Phone 14</h3>
            <p>Price: $79.99</p>
            <p>Rating: 4.5</p>
        </div>
        
        <div class="product">
            <img src="iphone14_pro.jpg" alt="iphone14 Pro" width="300" height="200">
            <h3>I-Phone 14 pro</h3>
            <p>Price: $89.99</p>
            <p>Rating: 4.3</p>
        </div>

        <div class="product">
            <img src="iphone14_proMax.jpg" alt="iphone14 Pro Max" width="300" height="200">
            <h3>I-Phone 14 Pro Max</h3>
            <p>Price: $119.99</p>
            <p>Rating 4.4</p>
        </div>

        
    </div>

    <div><p>Go to Home !! <a href="index.php">Click Here</a></p></div>
</body>
</html>
