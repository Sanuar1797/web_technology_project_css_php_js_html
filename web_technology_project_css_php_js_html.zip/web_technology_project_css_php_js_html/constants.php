<?php
session_start();

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","login_register");

define("DOMAIN","http://localhost/WebTech/project");

?>