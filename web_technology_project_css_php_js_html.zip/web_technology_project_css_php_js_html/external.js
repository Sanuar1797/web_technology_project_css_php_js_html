function isValid(pForm)
{
  const email = pForm.email.value;
  const password = pForm.password.value;

  const emailErrMsg = document.getElementById("emailErr");
  const passErrMsg = document.getElementById("passErr");

  emailErrMsg.innerHTML="";
  passErrMsg.innerHTML="";

  let flag = true;
  if(email==="")
  {
    emailErrMsg.innerHTML="Fill up the email";
    emailErrMsg.style.color="red";
    flag=false;
  }
  if(password==="")
  {
    passErrMsg.innerHTML="Fill Up the password";
    passErrMsg.style.color="red";
    flag=false;
  }

  return flag;
}



function isValidReg(pForm)
{
  const fullname = pForm.fullname.value;
  const email = pForm.email.value;
  const password = pForm.password.value;
  const repeat_password = pForm.repeat_password.value;
  const security_answer = pForm.security_answer.value;

  const fullnameErrMsg = document.getElementById("fnameErr");
  const emailErrMsg = document.getElementById("emailErr");
  const passErrMsg = document.getElementById("passErr");
  const repeatPassErrMsg = document.getElementById("repeatPassErr");
  const securityErrMsg = document.getElementById("securityErr");

  fullnameErrMsg.innerHTML="";
  emailErrMsg.innerHTML="";
  passErrMsg.innerHTML="";
  repeatPassErrMsg.innerHTML="";
  securityErrMsg.innerHTML="";

  let flag = true;
  if(email==="")
  {
    emailErrMsg.innerHTML="Fill up the email";
    emailErrMsg.style.color="red";
    flag=false;
    
  }
  if(password==="")
  {
    passErrMsg.innerHTML="Fill Up the password";
    passErrMsg.style.color="red";
    flag=false;
  }
  if(fullname==="")
  {
    fullnameErrMsg.innerHTML="Fill up the name";
    fullnameErrMsg.style.color="red";
    flag=false;
  }
  if(repeat_password==="")
  {
    repeatPassErrMsg.innerHTML="Fill up the password";
    repeatPassErrMsg.style.color="red";
    flag=false;
  }
  if(security_answer==="")
  {
    securityErrMsg.innerHTML="Fill up security answer";
    securityErrMsg.style.color="red";
    flag=false;
  }

  return flag;
}




function isValidForget(pForm)
{
  const fullname = pForm.fullname.value;
  const security_answer = pForm.security_answer.value;

  const fullnameErrMsg = document.getElementById("fnameErr");
  const securityErrMsg = document.getElementById("securityErr");

  fullnameErrMsg.innerHTML="";
  securityErrMsg.innerHTML="";

  let flag = true;
  if(fullname==="")
  {
    fullnameErrMsg.innerHTML="Fill up the name";
    fullnameErrMsg.style.color="red";
    flag=false;
  }
  if(security_answer==="")
  {
    securityErrMsg.innerHTML="Fill up security answer";
    securityErrMsg.style.color="red";
    flag=false;
  }

  return flag;
}



function isValidChangePass(pForm)
{
  const new_password = pForm.new_password.value;
  const password = pForm.password.value;

  const newpassErrMsg = document.getElementById("newpassErr");
  const passErrMsg = document.getElementById("passErr");

  newpassErrMsg.innerHTML="";
  passErrMsg.innerHTML="";

  let flag = true;
  if(new_password==="")
  {
    newpassErrMsg.innerHTML="Enter New Password !!";
    newpassErrMsg.style.color="red";
    flag=false;
  }
  if(password==="")
  {
    passErrMsg.innerHTML="Enter Current Password !!";
    passErrMsg.style.color="red";
    flag=false;
  }

  return flag;
}




function isValidUpdate(pForm)
{
  const new_fullname = pForm.new_fullname.value;
  const email = pForm.email.value;
  const new_email = pForm.new_email.value;

  const newfullnameErrMsg = document.getElementById("newfnameErr");
  const emailErrMsg = document.getElementById("emailErr");
  const newemailErrMsg = document.getElementById("newemailErr");

  newfullnameErrMsg.innerHTML="";
  emailErrMsg.innerHTML="";
  newemailErrMsg.innerHTML="";

  let flag = true;
  if(email==="")
  {
    emailErrMsg.innerHTML="Please enter current Email !!";
    emailErrMsg.style.color="red";
    flag=false;
    
  }
  if(new_fullname==="")
  {
    newfullnameErrMsg.innerHTML="Please enter New Name !!";
    newfullnameErrMsg.style.color="red";
    flag=false;
  }
  if(new_email==="")
  {
    newemailErrMsg.innerHTML="Please enter New Email !!";
    newemailErrMsg.style.color="red";
    flag=false;
    
  }
  
  return flag;
}




function isValidDelete(pForm)
{
  const email = pForm.email.value;
  
  const emailErrMsg = document.getElementById("emailErr");
  
  emailErrMsg.innerHTML="";

  let flag = true;
  if(email==="")
  {
    emailErrMsg.innerHTML="Fill up the email";
    emailErrMsg.style.color="red";
    flag=false;
  }

  return flag;
}