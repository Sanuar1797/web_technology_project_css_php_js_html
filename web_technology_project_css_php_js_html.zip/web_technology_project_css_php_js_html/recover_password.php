<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recover Password</title>
    <link rel="stylesheet" href="forget_password.css">
</head>

<body>
<div class="container">

<?php

$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "login_register";

$conn = new mysqli($hostName, $dbUser, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST["fullname"];
    $security_answer = $_POST["security_answer"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE full_name = ?");
    $stmt->bind_param("s", $fullname);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        
        
        if ($security_answer === $user['security_answer']) {
            
            $new_password = bin2hex(random_bytes(8)); 

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE full_name = ?");
            $update_stmt->bind_param("ss", $hashed_password, $fullname);
            $update_stmt->execute();
            $update_stmt->close();

            // echo "Your new password is: " . $new_password;
            echo '<p class="password-output">Your new password is: <b>' . $new_password . '</b></p>';
        } else {
            echo "Incorrect security answer.";
        }
    } else {
        echo "User not found.";
    }
}
$conn->close();
?>




    <div><a href="login.php" class="link">Login Here</a></div>
</div>
</body>
</html>

<!-- e188b5f493861713 -->